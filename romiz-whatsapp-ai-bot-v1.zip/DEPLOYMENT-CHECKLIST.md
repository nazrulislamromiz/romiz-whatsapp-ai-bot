# Deployment checklist

## Meta

[ ] Create/choose Meta Developer app
[ ] Add WhatsApp Business Platform
[ ] Create/configure WABA
[ ] Add/verify business phone number
[ ] Obtain Phone Number ID
[ ] Create System User and access token
[ ] Grant required WhatsApp permissions
[ ] Configure Webhooks
[ ] Subscribe WABA to webhook events
[ ] Test inbound message

## Server

[ ] Deploy Node.js 20+ app
[ ] Enable HTTPS
[ ] Add all `.env` values
[ ] Run `npm install`
[ ] Run `npm start`
[ ] Open `/` health endpoint
[ ] Verify `/webhook` with Meta
[ ] Send a test WhatsApp message

## OpenAI

[ ] Create API key
[ ] Add billing/credits as needed
[ ] Put key in `.env`
[ ] Never put key in frontend code
[ ] Choose a model available to your API project

## Production hardening

[ ] Persistent database
[ ] Secret management
[ ] Request logging without sensitive data
[ ] Rate limiting
[ ] Error monitoring
[ ] Backup strategy
[ ] Human support workflow
