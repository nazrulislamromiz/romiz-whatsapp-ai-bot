# ROMIZ WhatsApp AI Bot — v1

A first working backend for a real WhatsApp AI bot using the official WhatsApp Business Platform Cloud API and OpenAI Responses API.

## What this version does

- Receives WhatsApp text messages through a Meta webhook
- Sends the message to OpenAI
- Generates a Bangla/Banglish/English-friendly reply
- Sends the reply back through WhatsApp Cloud API
- Keeps short in-memory conversation history per WhatsApp number
- Supports `HUMAN` / `BOT` handover mode
- Ignores duplicate webhook message IDs
- Keeps secrets in `.env`, not frontend code

## 1. Requirements

- Node.js 20+
- A Meta Developer app with WhatsApp Business Platform configured
- A WhatsApp Business Account (WABA)
- A business phone number / phone number ID
- A System User access token with the required WhatsApp permissions
- An OpenAI API key
- A public HTTPS server for the webhook

Meta's Cloud API requires a Meta business portfolio, WABA and business phone number. Webhooks need a publicly reachable HTTPS endpoint. See the official Meta material for current setup details.

## 2. Install

```bash
npm install
```

Copy the environment template:

```bash
cp .env.example .env
```

Then edit `.env`.

At minimum set:

```env
GRAPH_API_VERSION=vXX.X
WHATSAPP_PHONE_NUMBER_ID=...
WHATSAPP_ACCESS_TOKEN=...
WEBHOOK_VERIFY_TOKEN=...
OPENAI_API_KEY=...
```

Use the Graph API version currently supported by your Meta app/dashboard rather than blindly copying an old version.

## 3. Start

```bash
npm start
```

Health check:

```text
https://YOUR-DOMAIN.example.com/
```

Expected JSON:

```json
{
  "ok": true,
  "service": "ROMIZ WhatsApp AI Bot",
  "version": "1.0.0"
}
```

## 4. Configure the Meta webhook

Set the callback URL to:

```text
https://YOUR-DOMAIN.example.com/webhook
```

Set the Verify Token to exactly the same value as:

```env
WEBHOOK_VERIFY_TOKEN=...
```

Subscribe the WhatsApp Business Account to webhook events as required by Meta.

For the first test, send a text message from a test/customer WhatsApp number to the business/test number.

## 5. Important production notes

### Access token
Use a System User token for a real deployment. Never commit it to GitHub.

### Database
This v1 uses RAM only. Restarting the server clears chat history and human-mode state.

For production, move conversation state and message IDs to Redis/Postgres.

### HTTPS
Meta webhook delivery requires a publicly reachable HTTPS endpoint. During development, use a secure tunnel or deploy the server to a host with HTTPS.

### Message policy / templates
WhatsApp messaging rules depend on the current Meta policies and conversation window. Business-initiated messages may require approved message templates. Check the current Meta documentation before sending outbound campaigns.

### Media
v1 handles incoming text only. Image/audio/document handling can be added next.

### Security
Do not expose `OPENAI_API_KEY` or `WHATSAPP_ACCESS_TOKEN` in browser JavaScript, GitHub Pages, screenshots or client-side code.

## Suggested next upgrades

1. PostgreSQL/Redis conversation storage
2. Admin dashboard
3. FAQ/knowledge-base upload
4. Customer ticket system
5. Human-agent inbox
6. Image/document understanding
7. Voice-message transcription
8. Analytics
9. Rate limiting and abuse protection
10. WhatsApp message templates
