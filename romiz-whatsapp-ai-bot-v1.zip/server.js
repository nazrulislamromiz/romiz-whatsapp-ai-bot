import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "2mb" }));

const PORT = Number(process.env.PORT || 3000);
const WEBHOOK_PATH = process.env.WEBHOOK_PATH || "/webhook";
const VERIFY_TOKEN = process.env.WEBHOOK_VERIFY_TOKEN;
const GRAPH_VERSION = process.env.GRAPH_API_VERSION;
const PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID;
const WA_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN;
const MODEL = process.env.OPENAI_MODEL || "gpt-6-luna";
const MAX_HISTORY = Number(process.env.MAX_HISTORY || 12);

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Demo-friendly in-memory storage.
// For production, replace this with Redis/Postgres/etc.
const conversations = new Map(); // waId -> [{role, content}]
const processedMessageIds = new Set();
const humanMode = new Set(); // waId values

const SYSTEM_INSTRUCTIONS = `
You are ${process.env.BOT_NAME || "ROMIZ WhatsApp AI"}, a helpful WhatsApp customer-support assistant.

Business:
- Name: ${process.env.BUSINESS_NAME || "Nazrul Islam Romiz"}
- WhatsApp: ${process.env.BUSINESS_WHATSAPP || "01734050726"}
- Facebook: ${process.env.BUSINESS_FACEBOOK || "https://www.facebook.com/ni.romiz.fbking"}

Rules:
- Reply naturally in the user's language. If the user writes Bangla, answer in Bangla. Banglish can be answered in simple Banglish or Bangla.
- Be concise and useful; WhatsApp-friendly formatting.
- Never claim you performed an action you did not perform.
- Never ask for passwords, OTP codes, access tokens, recovery codes, or other secrets.
- For Facebook/Instagram account recovery, give only legitimate official recovery/support guidance. Do not suggest bypassing security, CAPTCHA, rate limits, identity checks, or platform safeguards.
- If the customer needs a human, tell them a human can continue the conversation.
- Do not invent prices, guarantees, Meta decisions, or case outcomes.
- If you do not know something, say so and ask for the minimum useful information.
`;

function historyFor(waId) {
  if (!conversations.has(waId)) conversations.set(waId, []);
  return conversations.get(waId);
}

function remember(waId, role, content) {
  const h = historyFor(waId);
  h.push({ role, content });
  while (h.length > MAX_HISTORY) h.shift();
}

function extractIncomingMessages(body) {
  const result = [];
  for (const entry of body?.entry || []) {
    for (const change of entry?.changes || []) {
      const value = change?.value;
      if (!value?.messages) continue;

      for (const msg of value.messages) {
        if (msg.type === "text" && msg.text?.body && msg.from) {
          result.push({
            id: msg.id,
            from: msg.from,
            text: msg.text.body.trim()
          });
        }
      }
    }
  }
  return result;
}

async function sendWhatsAppText(to, body) {
  if (!GRAPH_VERSION || !PHONE_NUMBER_ID || !WA_TOKEN) {
    throw new Error("WhatsApp environment variables are missing.");
  }

  const url = `https://graph.facebook.com/${GRAPH_VERSION}/${PHONE_NUMBER_ID}/messages`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${WA_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: {
        preview_url: false,
        body
      }
    })
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(`WhatsApp API ${response.status}: ${JSON.stringify(data)}`);
  }
  return data;
}

async function generateAIReply(waId, userText) {
  const history = historyFor(waId);

  remember(waId, "user", userText);

  const response = await openai.responses.create({
    model: MODEL,
    instructions: SYSTEM_INSTRUCTIONS,
    input: history
  });

  const answer =
    response.output_text?.trim() ||
    "দুঃখিত, এই মুহূর্তে উত্তর তৈরি করতে পারছি না। একটু পরে আবার চেষ্টা করুন।";

  remember(waId, "assistant", answer);
  return answer;
}

async function handleIncoming(message) {
  const { id, from, text } = message;

  if (id && processedMessageIds.has(id)) return;
  if (id) {
    processedMessageIds.add(id);
    // Prevent unbounded growth in this first version.
    if (processedMessageIds.size > 10000) {
      const first = processedMessageIds.values().next().value;
      processedMessageIds.delete(first);
    }
  }

  const lower = text.toLowerCase();

  if (["human", "agent", "মানুষ", "এজেন্ট"].includes(lower)) {
    humanMode.add(from);
    await sendWhatsAppText(
      from,
      "ঠিক আছে। 🤝 Human support mode চালু করা হয়েছে। একজন মানুষ আপনার সাথে কথা চালিয়ে যাবে।\n\nBot আবার চালু করতে লিখুন: BOT"
    );
    return;
  }

  if (lower === "bot") {
    humanMode.delete(from);
    await sendWhatsAppText(from, "🤖 AI Bot আবার চালু হয়েছে। কীভাবে সাহায্য করতে পারি?");
    return;
  }

  if (humanMode.has(from)) return;

  const reply = await generateAIReply(from, text);
  await sendWhatsAppText(from, reply);
}

// Health check
app.get("/", (_req, res) => {
  res.json({
    ok: true,
    service: "ROMIZ WhatsApp AI Bot",
    version: "1.0.0"
  });
});

// Meta webhook verification
app.get(WEBHOOK_PATH, (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }

  return res.sendStatus(403);
});

// Incoming WhatsApp webhook
app.post(WEBHOOK_PATH, (req, res) => {
  // Acknowledge immediately so Meta does not wait for AI generation.
  res.sendStatus(200);

  const messages = extractIncomingMessages(req.body);
  for (const message of messages) {
    handleIncoming(message).catch((error) => {
      console.error("Message handling failed:", error);
    });
  }
});

app.listen(PORT, () => {
  console.log(`ROMIZ WhatsApp AI Bot running on port ${PORT}`);
  console.log(`Webhook: ${WEBHOOK_PATH}`);
});
